Comersus Sophisticated Cart Open Source
by Comersus Open Technologies LC
____________________________________________________________

1. Installation Notes
2. Important links
3. Contact Information

1. Installation Notes
For installation instructions refer to Comersus User's Guide.pdf file included with your distribution.
You will need Acrobat Reader, downloadable from 
http://www.adobe.com/products/acrobat/readstep.html

2. Important links
Free Technical assistance provided by Comersus Community
http://www.comersus.org/forum

Comersus Optional Power Packs and Services
http://www.comersus.com/purchase.html

3. Contact Information
		                        		    
Comersus Open Technologies
8345 NW 66th St #3537
Miami FL 33166-2626
http://www.comersus.com
Phone 1 (305) 735-8008

Errors, comments? contact us at http://www.comersus.com/contact.html